package com.SeharSana.HMS.exception;

public class RoomAlreadyBookedException extends  RuntimeException{
public  RoomAlreadyBookedException(String message){
    super(message);
}
}
