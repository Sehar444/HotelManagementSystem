package com.SeharSana.HMS.exception;

public class GuestNotFoundException extends RuntimeException{
    public GuestNotFoundException(String message) {
        super();
    }
}
