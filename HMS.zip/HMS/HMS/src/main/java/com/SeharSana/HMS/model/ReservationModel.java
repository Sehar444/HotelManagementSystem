package com.SeharSana.HMS.model;
import com.SeharSana.HMS.Repository.ReservationRepository;
import com.SeharSana.HMS.Utility.ReservationStatus;
import com.SeharSana.HMS.entity.Reservation;
import com.SeharSana.HMS.entity.Room;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;


@Component
@Data

public class ReservationModel {
    private Long id;
    private boolean checkIn;
    private boolean checkOut;
    private Date checkInDate;
    private Date checkOutDate;
    private boolean isCancelled;
    private String status;
    private RoomModel roomModel;
    private GuestModel guestModel;

    public Reservation disassemble() {
        Reservation reservation = new Reservation( );
        reservation.setId(id);
        reservation.setStatus(ReservationStatus.CHECKED_IN);
        reservation.setStatus(ReservationStatus.CHECKED_OUT);
        reservation.setStatus(ReservationStatus.CANCELLED);
        reservation.setCheckInDate(checkInDate);
        reservation.setCheckInDate(checkOutDate);
        reservation.isCheckIn();
        reservation.isCheckOut();
        reservation.setRoom(roomModel.disassemble( ));
        reservation.setGuest(guestModel.disassemble( ));


        return reservation;
    }

    public ReservationModel assemble(Reservation reservation) {
        ReservationModel reservationModel = new ReservationModel();
        reservationModel.setId(reservation.getId());
        reservationModel.setCheckIn(reservationModel.isCheckIn( ));
        reservationModel.setCheckOut(reservationModel.isCheckOut( ));
        reservationModel.setCheckInDate(reservation.getCheckInDate());
        reservationModel.setCheckOutDate(reservation.getCheckOutDate());
        reservationModel.setRoomModel(new RoomModel(reservation.getRoom( )).assemble(reservation.getRoom( )));
        reservationModel.setGuestModel(new GuestModel( ).assemble(reservation.getGuest( )));
        return reservationModel;
    }


//    public ReservationModel(Reservation reservation) {
//        this.ReservationId = reservation.getId( );
//        this.checkIn = reservation.isCheckIn( );
//        this.checkOut = (boolean) reservation.isCheckOut( );
//        this.roomModel = new RoomModel(reservation.getRoom() );
//        this.guestModel = new GuestModel(reservation.getGuest( ));
//    }
    public ReservationModel(){

    }
}




