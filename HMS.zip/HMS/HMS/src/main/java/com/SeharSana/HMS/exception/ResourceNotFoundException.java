package com.SeharSana.HMS.exception;

public class ResourceNotFoundException extends Exception{
    public ResourceNotFoundException(String msg, String id, long l) {
        super(msg);
    }
    public void RuntimeException(String msg){

    }
}
