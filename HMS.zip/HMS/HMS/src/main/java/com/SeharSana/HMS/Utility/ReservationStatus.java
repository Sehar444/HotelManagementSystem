package com.SeharSana.HMS.Utility;

public enum ReservationStatus {
    PENDING,
    CHECKED_IN,
    CHECKED_OUT,
    PAID, CANCELLED
}
