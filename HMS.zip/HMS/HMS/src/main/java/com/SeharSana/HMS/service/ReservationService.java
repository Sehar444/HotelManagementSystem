package com.SeharSana.HMS.service;

import com.SeharSana.HMS.Repository.ReservationRepository;
import com.SeharSana.HMS.entity.Reservation;
import com.SeharSana.HMS.entity.Room;
import com.SeharSana.HMS.model.ReservationModel;
import com.SeharSana.HMS.model.RoomModel;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.util.List;
import java.util.Optional;

@Service
public class ReservationService {

    @Autowired
    private ReservationRepository reservationRepository;
    public ReservationModel createReservation(ReservationModel reservationModel)

    {
        return reservationModel.assemble(reservationRepository.save(reservationModel.disassemble()));
    }

    public List<Reservation> getAllReservations() {
        return reservationRepository.findAll();
    }

    public Reservation getReservationById(Long id)
    {
        Optional<Reservation> reservation = reservationRepository.findById(id);
        if (reservation.isPresent( )) {
            return reservation.get( );
        } else
        {
            throw new EntityNotFoundException("Reservation with id " + id + " not found.");
        }
    }


    public Reservation updateReservation(Long id, Reservation reservationUpdates)
    {
        Optional<Reservation> reservation = reservationRepository.findById(id);
        if (reservation.isPresent( )) {
            Reservation existingReservation = reservation.get( );
            existingReservation.setCheckIn(reservationUpdates.isCheckIn( ));
            existingReservation.setCheckOut(reservationUpdates.isCheckOut( ));
            existingReservation.setStatus(reservationUpdates.getStatus( ));
            existingReservation.setCheckInDate(reservationUpdates.getCheckInDate());
            existingReservation.setCheckOut(reservationUpdates.getCheckOutDate());
            existingReservation.setGuest(reservationUpdates.getGuest( ));
            existingReservation.setRoom(reservationUpdates.getRoom( ));
            return reservationRepository.save(existingReservation);
        } else
        {
            throw new EntityNotFoundException("Reservation with id " + id + " not found.");
        }
    }
    public boolean isCheckInDateAvailable(RoomModel roomModel, Date checkInDate) {
        List<ReservationModel> reservations = reservationRepository.findByRoom(roomModel.disassemble());
        for (ReservationModel reservationModel : reservations) {
            Date reservedCheckInDate = (Date) reservationModel.getCheckInDate();
            Date reservedCheckOutDate = (Date) reservationModel.getCheckOutDate();
            if (checkInDate.after(reservedCheckInDate) && checkInDate.before(reservedCheckOutDate)) {
                return false;
            }
            if (checkInDate.equals(reservedCheckInDate) || checkInDate.equals(reservedCheckOutDate)) {
                return false;
            }
        }
        return true;
    }


    public void deleteReservation(Long id)
    {
        Optional<Reservation> reservation = reservationRepository.findById(id);
        if (reservation.isPresent( ))
        {
            reservationRepository.deleteById(id);
        } else
        {
            throw new EntityNotFoundException("Reservation with id " + id + " not found.");
        }
    }
}